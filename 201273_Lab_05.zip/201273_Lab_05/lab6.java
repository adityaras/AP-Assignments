import java.util.*;

abstract class Tiles
{
    public abstract int move_new_loc(ArrayList <Tile> Arr,int curr);
    public abstract void reveal_tile() throws SnakeBiteException, CricketBiteException, VultureBiteException, TrampolineException, WhiteException;
}
class Tile extends Tiles
{
    private int type;
    private int new_loc;

    @Override
    public  int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
        curr=curr+new_loc;
        return curr;

    }
    
    @Override
    public void reveal_tile() throws SnakeBiteException, CricketBiteException, VultureBiteException, TrampolineException, WhiteException
    {
        System.out.println("\tRevealing Identity of Tile");
        if(type==1)
        {
            throw new SnakeBiteException("\tYou Have Been bitten by a Snake");
        }
        else if(type==2)
        {
            throw new CricketBiteException("\tYou Have Been bitten by a Cricket");
        }
        else if(type==3)
        {
            throw new VultureBiteException("\tYou Have Been bitten by a Vulture");
        }
        else if(type==4)
        {
            throw new TrampolineException("\tCongratulations, You have found a Trampoline");
        }
        else if(type==5)
        {
            throw new WhiteException("\tYou are on a White Tile");
        }

    }
    /**
     * @param type the type to set
     */
    public void setType(int type) {
        this.type = type;
    }
    /**
     * @return the new_loc
     */
    public int getNew_loc() {
        return new_loc;
    }
    /**
     * @param new_loc the new_loc to set
     */
    public void setNew_loc(int new_loc) {
        this.new_loc = new_loc;
    }
    
    
}

class Snake extends Tile
{
    private final int type=1;
    private final int new_loc;
    Snake(int assign)
    {
        new_loc=-assign;
        super.setNew_loc(this.new_loc);
        super.setType(this.type);
    }

    @Override
    public int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
     
        return super.move_new_loc(Arr, curr);
        
    }
}
class Cricket extends Tile
{
    
    private final int type=2;
    private final int new_loc;
    
    Cricket(int assign)
    {
        new_loc=-assign;
        super.setNew_loc(this.new_loc);
        super.setType(this.type);
    }

    @Override
    public int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
        return super.move_new_loc(Arr, curr);

    }
}
class Vulture extends Tile
{

    private final int type=3;
    private final int new_loc;
    Vulture(int assign)
    {
        new_loc=-assign;
        super.setNew_loc(this.new_loc);
        super.setType(this.type);
    }
  
    @Override
    public int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
        return super.move_new_loc(Arr, curr);

    }
}
class Trampoline extends Tile
{
   
    private final int type=4;
    private final int new_loc;
    Trampoline(int assign)
    
    {
        new_loc=assign;
        super.setNew_loc(this.new_loc);
        super.setType(this.type);
    }
 
    @Override
    public int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
        return super.move_new_loc(Arr, curr);
    }
}
class White extends Tile
{
    private final int type=5;
    private final int new_loc=0;
    White()
    {
        super.setType(this.type);
        super.setNew_loc(this.new_loc);
    }
 
    @Override
    public int move_new_loc(ArrayList <Tile> Arr,int curr)
    {
   
   
        return 0;    }


}
abstract class MyExceptions extends Exception
{
    private static final long serialVersionUID = 1L;
    MyExceptions(String message)
    {
        super(message);
    }
    	

}

class SnakeTileException extends MyExceptions
{
   
    private static final long serialVersionUID = 1L;
    SnakeTileException(String message)
    {
        super(message);
    }

}
class VultureTileException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    VultureTileException(String message)
    {
        super(message);
    }

}
class CricketTileException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    CricketTileException(String message)
    {
        super(message);
    }

}
class TrampolineTileException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    TrampolineTileException(String message)
    {
        super(message);
    }

}

class SnakeBiteException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    SnakeBiteException(String message)
    {
        super(message);
    }

}
class VultureBiteException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    VultureBiteException(String message)
    {
        super(message);
    }

}
class CricketBiteException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    CricketBiteException(String message)
    {
        super(message);
    }

}
class TrampolineException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    TrampolineException(String message)
    {
        super(message);
    }
}
class WhiteException extends MyExceptions
{
    private static final long serialVersionUID = 1L;
    WhiteException(String message)
    {
        super(message);
    }

}
class GameWinnerException extends MyExceptions
{
    private static final long serialVersionUID = 1L;

    GameWinnerException(String message)
    {
        super(message);
    
    }
}


class Game
{
    private int tile_ind=0;
    private int roll_counter;
    private final String name;
    private final int no_of_tiles;
    private final int max_val_obs;
    private final int min_val_obs;
    private int no_snakes;
    private int no_vultures;
    private int no_cricket;
    private int no_trampoline;
    private int no_snakes_fin;
    private int no_vultures_fin;
    private int no_cricket_fin;
    private int no_trampoline_fin;    
    private final int snake_move;
    private final int vulture_move;
    private final int cricket_move;
    private final int trampoline_jump;
    private int no_of_tiles_1;
    private String name_1;     
    private int snake_counter;
    private int vulture_counter;
    private int cricket_counter;
    private int trampoline_counter;
    private ArrayList <Tile> Layout=new ArrayList<>();
    Game()
    {
        System.out.println("**************** Welcome to The Game ****************");
        Boolean done = false;
        while (!done) {
            System.out.println("Enter No. of Tiles");
            try{
                Scanner inpu=new Scanner(System.in);
                no_of_tiles_1 = inpu.nextInt();
                done = true;
                
            }
            catch(InputMismatchException inp){
                System.out.println("Wrong input, Try Again");
            }

        } 
        no_of_tiles=no_of_tiles_1;
        System.out.println("Setting Up the Race Track");
        
        System.out.println(no_of_tiles);
        min_val_obs=(int)(0.05*no_of_tiles);
        max_val_obs=(int)(0.125*no_of_tiles);
        //System.out.println(min_val_obs);
        //System.out.println(max_val_obs);
        //min_val_obs=Integer.parseInt(String.valueOf(0.05*no_of_tiles));
        //max_val_obs=Integer.parseInt(String.valueOf(0.125*no_of_tiles));
        Random assigner=new Random();
        no_snakes=assigner.nextInt(max_val_obs)+min_val_obs;
        no_snakes_fin=no_snakes;
        //System.out.println("yeah        "+no_snakes);
        no_vultures=assigner.nextInt(max_val_obs)+min_val_obs;
        no_vultures_fin=no_vultures;
        no_cricket=assigner.nextInt(max_val_obs)+min_val_obs;
        no_cricket_fin=no_cricket;
        no_trampoline=assigner.nextInt(max_val_obs)+min_val_obs;
        no_trampoline_fin=no_trampoline;
        System.out.println("DANGER: "+ "There are "+no_snakes+", "+no_vultures+", "+no_cricket +" Snakes, Vultures, Crickets on your Track");
        snake_move=assigner.nextInt(10)+1;
        vulture_move=assigner.nextInt(11)+1;
        cricket_move=assigner.nextInt(9)+1;
        trampoline_jump=assigner.nextInt(10)+1;
        System.out.println("DANGER: "+"Each Snake, Vulture & Cricket send you back by "+snake_move+", "+vulture_move+", "+cricket_move+" tiles respectively");
        System.out.println("Good News, You have "+no_trampoline+" Trampolines on your Track");
        System.out.println("Good News, Each Trampoline gives you a jump of "+trampoline_jump+" Tiles.");
        Boolean done_1 = false;
        while (!done_1) {
            System.out.println("Enter Player Name");
            try{
                 Scanner inpu=new Scanner(System.in);     
               
                name_1=inpu.nextLine();
                
                done_1=true;
                
                             
            }
            catch(InputMismatchException inp){
                System.out.println("Wrong input, Try Again");
            }

        } 
        name=name_1;
        Boolean done_2 = false;
        while (!done_2) {
            //System.out.println("ya3y");
            System.out.println("Enter to continue");
            try{
                Scanner inpu=new Scanner(System.in);
                String name_2=inpu.nextLine();
              //  System.out.println("ya1y");
                done_2=true;
                if (name_2.length()>0)
                {
                  //  System.out.println("ya2y");
                    done_2=false;
                    throw new InputMismatchException("");
                }
                             
            }
            catch(InputMismatchException inp){
                System.out.println("Wrong input, Try Again");
            }

        } 
        for(int i=0;i<no_of_tiles;i++)
        {
            Tile temp=new White();
            Layout.add(temp);
           // System.out.println("ya4y");
        }
        int y = Layout.size();
        for (int i1=0;i1<y;i1=i1+assigner.nextInt(4)+1)
        {
           // System.out.println("ya5y");
           // System.out.println(i1);
            if(!((i1+1)%6==0))

            {
                
                int selector = assigner.nextInt(4)+1;
                //System.out.println("selector is "+selector);
                //System.out.println("hbwWLGJHE "+no_snakes);
                try {
                    if (selector==1 && no_snakes_fin>0)
                    {
                        no_snakes_fin--;
                        throw new SnakeTileException("123");
                    }
                    else if(selector==2 && no_cricket_fin>0)
                    {
                        no_cricket_fin--;
                        throw new CricketTileException("123");

                    }
                    else if(selector==3 && no_vultures_fin>0)
                    {
                        no_vultures_fin--;
                        throw new VultureTileException("123");
                    }
                    else if(selector==4 && no_trampoline_fin>0)
                    {
                        no_trampoline_fin--;
                        throw new TrampolineTileException("123");
                    }
                    else if( no_snakes_fin + no_cricket_fin + no_vultures_fin + no_trampoline_fin >0 )
                    {
                        i1--;
                    }
                } catch (SnakeTileException e) 
                {
                    //System.out.println("dghgiusebgkbbikarbiiu");
                    Tile element=new Snake(snake_move);
                    Layout.remove(i1);
                    Layout.add(i1, element);
                }
                catch (CricketTileException e) 
                {
                    //System.out.println("dghgiusebgkbbikarbiiu");

                    Tile element=new Cricket(cricket_move);
                    Layout.remove(i1);

                    Layout.add(i1, element);
                }
                catch (VultureTileException e) 
                {     //               System.out.println("dghgiusebgkbbikarbiiu");

                    Tile element=new Vulture(vulture_move);
                    Layout.remove(i1);
                    Layout.add(i1, element);
                }
                catch (TrampolineTileException e) 
                {
                    //System.out.println("dghgiusebgkbbikarbiiu");

                    Tile element=new Trampoline(trampoline_jump);
                    Layout.remove(i1);
                    Layout.add(i1, element);
                    
                }
            }
        }
       // System.out.println(Layout);
        System.out.println("Starting Game with "+name);
        System.out.println("Transferring Control to Computer");
        System.out.println("Game Starting Now ================================>");
        playgame();
        
    }
    /**
     * @return the max_val_obs
     */
    public int getMax_val_obs() {
        return max_val_obs;
    }
    /**
     * @return the layout
     */
    public ArrayList<Tile> getLayout() {
        return Layout;
    }/**
     * @return the min_val_obs
     */
    public int getMin_val_obs() {
        return min_val_obs;
    }
    /**
     * @return the no_of_tiles
     */
    public int getNo_of_tiles() {
        return no_of_tiles;
    }
    /**
     * @param layout the layout to set
     */
    public void setLayout(ArrayList<Tile> layout) {
        Layout = layout;
    }
    public void playgame()
    {
        int dic_value;
        Boolean race_finish=false;
        while(!race_finish)
        {
        if(tile_ind==0)
            {do {
            roll_counter++;
            dic_value=roll_dice();
            if(dic_value!=6)
            {            
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value+". You need a 6 to break free.");
            }
            else 
            {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value+" You get a free Roll");
            }

        } while (dic_value!=6);

        
        roll_counter++;
        dic_value=roll_dice();}

        else 
        {
            roll_counter++;
            dic_value=roll_dice();
        }
        if(dic_value+tile_ind>no_of_tiles)
        {
            System.out.println("\tYou are on Tile No."+tile_ind);
            System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value+", You can not go ahead");
        }
        else if(dic_value+tile_ind==no_of_tiles)
        {
            try {
                roll_counter++;
                tile_ind=tile_ind+dic_value;
                throw new GameWinnerException("");
            } catch (GameWinnerException e) {
                System.out.println("[Roll No.: "+roll_counter+"]: "+name+" rolled a "+dic_value);

                System.out.println("You Won, Congratulations "+name);
                System.out.println("\tYou took "+roll_counter+" Rolls to Win");
                System.out.println("\tNo. of Snake Bites "+snake_counter);
                System.out.println("\tNo. of Vulture Bites "+vulture_counter);
                System.out.println("\tNo. of Cricket Bites "+cricket_counter);
                System.out.println("\tNo. of Trampoline Jumps "+trampoline_counter);
                race_finish=true;
            }
        }
        else 
        {
            
            tile_ind+=dic_value;
          {
                try {
                Layout.get(tile_ind).reveal_tile();
            
            } catch (SnakeBiteException e) {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value);
                System.out.println("\tYou are on Tile No."+tile_ind);
                System.out.println(e.getMessage());
                snake_counter++;
                //System.out.println("Adder for Snake "+Layout.get(tile_ind).move_new_loc(Layout, tile_ind));
                tile_ind=Layout.get(tile_ind).move_new_loc(Layout, tile_ind);
                if(tile_ind<0)
                {
                    tile_ind=0;
                }
               
            }
            catch (VultureBiteException e) {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value);
                System.out.println("\tYou are on Tile No."+tile_ind);
                System.out.println(e.getMessage());
                vulture_counter++;
                tile_ind=Layout.get(tile_ind).move_new_loc(Layout, tile_ind);
                if(tile_ind<0)
                {
                    tile_ind=0;
                }
               
            }
            catch (CricketBiteException e) {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value);
                System.out.println("\tYou are on Tile No."+tile_ind);
                System.out.println(e.getMessage());
                cricket_counter++;
                tile_ind=Layout.get(tile_ind).move_new_loc(Layout, tile_ind);
                if(tile_ind<0)
                {
                    tile_ind=0;
                }
               
            }
            catch (TrampolineException e) {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value);
                System.out.println("\tYou are on Tile No."+tile_ind);
                System.out.println(e.getMessage());
                trampoline_counter++;
                tile_ind=Layout.get(tile_ind).move_new_loc(Layout, tile_ind);
                if(tile_ind<0)
                {
                    tile_ind=0;
                }
                
               
            }
            catch (WhiteException e) {
                System.out.println("[Roll No: "+roll_counter+"]: "+name+" rolled a "+dic_value);
                System.out.println("\tYou are on Tile No."+tile_ind);
                System.out.println(e.getMessage());

                tile_ind+=Layout.get(tile_ind).move_new_loc(Layout, tile_ind);
                if(tile_ind<0)
                {
                    tile_ind=0;
                }

               
            }
        }
            
        }

    }
    }
    public void endGame()
    {
        
        System.out.println("Game Finished");
    }
    public int roll_dice()
    {
        Random dic_no=new Random();
        return dic_no.nextInt(6)+1;
    }
}
class lab6
{
        public static void main(String[] args) 
    {
        Game startGame=new Game();
        startGame.endGame();        
    }
}