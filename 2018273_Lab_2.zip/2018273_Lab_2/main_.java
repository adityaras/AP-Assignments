import java.util.*;
import java.lang.Math;
interface transaction
{
    void print();
    void search();
}
class item implements transaction
{
    
    private int code;
    private int price;
    private String name;
    private int quatity;
    private String category;
    private int offer_cond=0;
    item(int code, String name, int quatity, int price,String category, int offer_cond)
    {
        this.code=code;
        this.name=name;
        this.quatity=quatity;
        this.category=category;
        this.price=price;
        this.offer_cond=offer_cond;
    }
    /**
     * @return the price
     */
    public int getPrice() {
        return price;
    }
    /**
     * @param price the price to set
     */
    public void setPrice(int price) {
        this.price = price;
    }
    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }
    /**
     * @param code the code to set
     */
    public void setCode(int code) {
        this.code = code;
    }
    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }
    
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }/**
     * @return the offer_cond
     */
    public int getOffer_cond() {
        return offer_cond;
    }/**
     * @return the quatity
     */
    public int getQuatity() {
        return quatity;
    }
    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }/**
     * @param offer_cond the offer_cond to set
     */
    public void setOffer_cond(int offer_cond) {
        this.offer_cond = offer_cond;
    }
    /**
     * @param quatity the quatity to set
     */
    public void setQuatity(int quatity) {
        this.quatity = quatity;
    }
    public void search()
    {
        System.out.println("yay");
    }
    public void print()
    {
        String stroffer;
        if(this.offer_cond==2)
        {
            stroffer="25% Off";
        }
        else if(this.offer_cond==1)
        {
            stroffer="BOGO";
        }
        else 
        {
            stroffer="Sorry No Offer";
        }
        
        System.out.print("Code: "+this.code+" "+"Name: "+this.name+" "+"Price: Rs."+this.price+" "+"Quantity: "+this.quatity+" "+"Offer: "+stroffer+" "+"Category: "+this.category);
        System.out.println();
    }
    
}
class merchant implements transaction
{
    private Double comp_bal;
    private Double calc_com_bal;
    private int rewardslots;
    private int allowed_length;
    private String name;
    private String address;
    ArrayList<item> item_list=new ArrayList<>();
    ArrayList<String> categories=new ArrayList<>();
    merchant(String name,String address)
    {
        this.name=name;
        this.address=address;
        this.allowed_length=10;
        this.rewardslots=0;

    }
    
    /**
     * @return the calc_com_bal
     */
    public Double getCalc_com_bal() {
        return calc_com_bal;
    }
    /**
     * @param calc_com_bal the calc_com_bal to set
     */
    public void setCalc_com_bal(Double calc_com_bal) {
        this.calc_com_bal = calc_com_bal;
    }
    
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @return the allowed_length
     */
    public int getAllowed_length() {
        return allowed_length;
    }
    /**
     * @return the rewardslots
     */
    public int getRewardslots() {
        return rewardslots;
    }
    /**
     * @return the comp_bal
     */
    public Double getComp_bal() {
        return comp_bal;
    }
    /**
     * @param comp_bal the comp_bal to set
     */
    public void setComp_bal(Double comp_bal) {
        this.comp_bal = comp_bal;
    }
    /**
     * @param rewardslots the rewardslots to set
     */
    public void setRewardslots(int rewardslots) {
        this.rewardslots = rewardslots;
    }
    /**
     * @param allowed_length the allowed_length to set
     */
    public void setAllowed_length(int allowed_length) {
        this.allowed_length = allowed_length;
    }
    public void search()
    {
        System.out.println("yay2");
    }
    public void print()
    {
        System.out.println("Name: "+this.name);
        System.out.println("Address: "+this.address);
        System.out.println("Contribution: Rs."+this.comp_bal);
    }
    public void additem(int code, String name, int quatity,int price, String category, int offer_cond)
    {
        
        
        if (item_list.size()<=allowed_length)
        {
            item temp=new item(code, name, quatity,price, category, offer_cond);
            item_list.add(temp);
            temp.print();
            
        }
        else
        {
            System.out.println("Error");
        }

    }
    public void edititems(int code, int price, int quantity)
    {
        for(int i=0;i<item_list.size();i++)
        {
            if (item_list.get(i).getCode()==code)
            {
                item_list.get(i).setQuatity(quantity);
                item_list.get(i).setPrice(price);
                item_list.get(i).print();
            }
        }
    }
    
    public void search(String category,ArrayList<item> items_list_universal)
    {
        for(int j=0;j<items_list_universal.size();j++)
        {
         if(items_list_universal.get(j).getCategory().equals(category)) 
         {
             items_list_universal.get(j).print();
         } 
        }
    }
    public void add_offer(int code,int offer_cond)
    {
        for(int k=0;k<item_list.size();k++)
        {
            if(item_list.get(k).getCode()==code)
            {
                item_list.get(k).setOffer_cond(offer_cond);
                item_list.get(k).print();
            }
        }
    }
    public void show_slots()
    {
        rewardslots=allowed_length-10;
        System.out.println(rewardslots);
    }
    

}
class customer implements transaction
{
    private String Name;
    private String Address;
    private int no_order_placed;
    private Double money;
    private int reward;
    ArrayList<item> order_history=new ArrayList<>();
    ArrayList<item> cart=new ArrayList<>();
    customer(String name,String Address)
    {
        this.Name=name;
        this.Address=Address;
        this.money=100.0;
    }
    /**
     * @return the address
     */
    public String getAddress() {
        return Address;
    }
    /**
     * @return the reward
     */
    public int getReward() {
        return reward;
    }
    /**
     * @param reward the reward to set
     */
    public void setReward(int reward) {
        this.reward = reward;
    }
    /**
     * @return the money
     */
    public Double getMoney() {
        return money;
    }
    /**
     * @param money the money to set
     */
    public void setMoney(Double money) {
        this.money = money;
    }
    /**
     * @return the name
     */
    public String getName() {
        return Name;
    }/**
     * @return the no_order_placed
     */
    public int getNo_order_placed() {
        return no_order_placed;
    }
    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        Address = address;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        Name = name;
    }
    /**
     * @param no_order_placed the no_order_placed to set
     */
    public void setNo_order_placed(int no_order_placed) {
        this.no_order_placed = no_order_placed;
    }
    public void search()
    {

    }
    public void search_c(item temp,int quantity,int buying_choice,ArrayList<item> items_list_universal)
    {
        if(buying_choice==2)
        {
            temp.setQuatity(quantity);
            cart.add(temp);
        }
        else if(buying_choice==1)
        {
            buy(temp,items_list_universal);
            
        }
    }
    public void buy(item temp,ArrayList<item> items_list_universal)
    {
        int a1=0;
        no_order_placed++;
        money=money+reward;
        for(int a12=0;a1<items_list_universal.size();a12++)
        {
            if(temp.getCode()==items_list_universal.get(a12).getCode())
            {
                a1=a12;
                break;
            }
        }
        if(temp.getQuatity()<items_list_universal.get(a1).getQuatity())
        {
            if(temp.getOffer_cond()==1)
            {
                temp.setQuatity(2*temp.getQuatity());
                if(temp.getQuatity()<items_list_universal.get(a1).getQuatity())
                {
                    order_history.add(temp);
                    items_list_universal.get(a1).setQuatity(items_list_universal.get(a1).getQuatity()-temp.getQuatity());
                    money=money-(temp.getPrice()*temp.getQuatity()*0.5);
                    
                }
                else
                {
                    System.out.println("Out of Stock");
                }
            }
            if(temp.getOffer_cond()==2)
            {
                money=money-(temp.getPrice()*temp.getQuatity());
                money=money*0.75;
                order_history.add(temp);
                items_list_universal.get(a1).setQuatity(items_list_universal.get(a1).getQuatity()-temp.getQuatity());


            }
            if(temp.getOffer_cond()==0)
            {
                money=money-(temp.getPrice()*temp.getQuatity());
                order_history.add(temp);
                items_list_universal.add(temp);
            }

        }
        else
        {
            System.out.println("Out of Stock");
        }


    }
    public void checkout(ArrayList<item> items_list_universal)
    {
        no_order_placed++;
        int sum=0;
        int flag=0;
        int checker=0;
        money=money+reward;
        for(int i=0;i<cart.size();i++)
        {
            if(cart.get(i).getQuatity()!=0)
            {
                sum+=(cart.get(i).getPrice())*(cart.get(i).getQuatity());
                checker++;
            }
            if (sum>money)
            {
                
                flag=1;
                break;
            }
            if(cart.get(i).getQuatity()==0)
            {
                flag=2;
            }
        }
        if (checker==0)
        {
            checker=cart.size()+1;
        }
        checker=Math.min(checker,cart.size());
        for(int i1=0;i1<checker;checker--)
        {
            buy(cart.get(i1), items_list_universal);
        }
        if(flag==0)
        {
            System.out.println("Successfully Bought, Congratulations");
        }
        else if(flag==1)
        {
            System.out.println("Out of Money, Maximum Items Bought. Enjoy");
        }
        else if(flag==2)
        {
            System.out.println("Out of Stock");
        }
        if (no_order_placed%5==0){
            reward=reward+10;
        }
    }
    @Override
    public void print()
    {
        System.out.println("Reward: "+reward);
    }
    public void recent_orders()
    {
        int var=Math.min(10,order_history.size());
        for(int j=0;j<var;j++)
        {
            order_history.get(j).print();
        }
    }
}
class main_
{
  public static void main(String[] args)
  {
    
    Scanner inpu=new Scanner(System.in);
    int tot_com_bal=0;
    HashSet<String> categories = new HashSet<String>();
    ArrayList<item> items_list_universal=new ArrayList<>();
    ArrayList<customer> all_customers=new ArrayList<>();
    ArrayList<merchant> all_merchants=new ArrayList<>();

    customer c1=new customer("Ali","Okhla Vihar");
    customer c2=new customer("Aditya","Noida");
    customer c3=new customer("Nobita","Japan");
    customer c4=new customer("Thor","Midgard");
    customer c5=new customer("Manan","East of Kailash");
    all_customers.add(c1);
    all_customers.add(c2);
    all_customers.add(c3);
    all_customers.add(c4);
    all_customers.add(c5);

    merchant m1 =new merchant("Gupta Traders", "Nehru Place");
    merchant m2=new merchant("Singh Associates", "DaryaganJ");
    merchant m3=new merchant("Rastogi & Sons", "Noida");
    merchant m4=new merchant("Miniso", "Japan");
    merchant m5=new merchant("Magic Shop", "Midgard");
    all_merchants.add(m1);
    all_merchants.add(m2);
    all_merchants.add(m3);
    all_merchants.add(m4);
    all_merchants.add(m5);

    while(true)
    {
        int choice_var;
        System.out.println("Welcome To Mercury");
        System.out.println("1) Enter as Merchant");
        System.out.println("2) Enter as Customer");
        System.out.println("3) See User Details");
        System.out.println("4) View Net Company Balance");
        System.out.println("Press any other key to exit");
        choice_var=inpu.nextInt();
        if(choice_var==1)
        {
            while(true)
            {
                int choice_var_merchant;
                System.out.println("Merchant Menu");
                for(int i=0;i<all_merchants.size();i++)
                {
                    System.out.println(i+1+") "+all_merchants.get(i).getName());
                }
                System.out.println("Press any other key to exit");
                System.out.println("Enter Choice");
                choice_var_merchant=inpu.nextInt();
                int chosen_merchant=choice_var_merchant-1;
                if(chosen_merchant>all_merchants.size()-1)
                {
                    break;
                }
                System.out.println("Welcome "+all_merchants.get(chosen_merchant).getName());
                System.out.println("1) Add Item");
                System.out.println("2) Edit Item");
                System.out.println("3) Search by Category");
                System.out.println("4) Add Offer");
                System.out.println("5) Rewards Won");
                System.out.println("Press any other key to exit");
                System.out.println("Enter Choice");
                int choice_var_merch_menu=inpu.nextInt();
                if(choice_var_merch_menu==1)
                {
                    String name;
                    String category;
                    int quantity;
                    int code;
                    int price;
                    int offer_cond;
                    code=items_list_universal.size()+1;
                    System.out.println("Enter Name");
                    inpu.nextLine();
                    name=inpu.nextLine();
                    System.out.println("Enter Quantity ");
                    quantity=inpu.nextInt();
                    System.out.println("Enter Price");
                    price=inpu.nextInt();
                    System.out.println("Enter Category ");
                    inpu.nextLine();
                    category=inpu.nextLine();
                    offer_cond=0;
                    categories.add(category);
                    all_merchants.get(choice_var_merchant).additem(code,name,quantity,price,category,offer_cond);
                    item temp1Item=new item(code, name, quantity,price, category, offer_cond);
                    items_list_universal.add(temp1Item);
                    boolean fl1=true;
                    for(int i1=0;i1<all_merchants.get(choice_var_merchant).categories.size();i1++)
                    {
                        if(all_merchants.get(choice_var_merchant).categories.get(i1).equals(category))
                        {
                            fl1=false;
                            break;
                        }
                    }
                    if(fl1==true)
                    {
                    all_merchants.get(choice_var_merchant).categories.add(category);
                    }
                }
                else if(choice_var_merch_menu==2)
                {
                    System.out.println("Enter Item Code: ");
                 
                    for(int j=0;j<all_merchants.get(choice_var_merchant).item_list.size();j++)
                    {
                        System.out.println("e"+all_merchants.get(choice_var_merchant).item_list.size());
                        
                        all_merchants.get(choice_var_merchant).item_list.get(j).print();
                    }
                    int code2=inpu.nextInt();
                    System.out.println("Enter Item Price");
                    int price1=inpu.nextInt();
                    System.out.println("Enter Item Quantity");
                    int quantity1=inpu.nextInt();
                    for(int j1=0;j1<items_list_universal.size();j1++)
                    {
                        if(items_list_universal.get(j1).getCode()==code2)
                        {
                            items_list_universal.get(j1).setQuatity(quantity1);
                            items_list_universal.get(j1).setPrice(price1);
                            
                        }
                    }
                    for(int j2=0;j2<all_merchants.get(choice_var_merchant).item_list.size();j2++)
                    {
                        if(all_merchants.get(choice_var_merchant).item_list.get(j2).getCode()==code2)
                        {
                            all_merchants.get(choice_var_merchant).item_list.get(j2).setPrice(price1);
                            all_merchants.get(choice_var_merchant).item_list.get(j2).setQuatity(quantity1);
                            all_merchants.get(choice_var_merchant).item_list.get(j2).print();
                        }
                    }



                }
                else if(choice_var_merch_menu==3)
                {
                    System.out.println("Enter Choice in string format");
                    Iterator<String> str = categories.iterator(); 
                    while (str.hasNext())
                    {
                        System.out.println(str.next());
                    }
                    String cat=inpu.nextLine();
                    for(int k=0;k<items_list_universal.size();k++)
                    {
                        if(items_list_universal.get(k).getCategory().equals(cat))
                        {
                            items_list_universal.get(k).print();
                        }
                    }

                }
                else if(choice_var_merch_menu==4)
                {
                    System.out.println("Enter Item Code: ");
                    int code3=inpu.nextInt();
                    System.out.println("Choose Offer");
                    System.out.println("1) BOGO");
                    System.out.println("2) 25% off");
                    int offer_cond_2=inpu.nextInt();

                    for(int l=0;l<items_list_universal.size();l++)
                    {
                        if(items_list_universal.get(l).getCode()==code3)
                        {
                            items_list_universal.get(l).setOffer_cond(offer_cond_2);
                            items_list_universal.get(l).print();
                            
                        }
                    }
                    for(int l2=0;l2<all_merchants.get(choice_var_merchant).item_list.size();l2++)
                    {
                        if(all_merchants.get(choice_var_merchant).item_list.get(l2).getCode()==code3)
                        {
                            all_merchants.get(choice_var_merchant).item_list.get(l2).setPrice(offer_cond_2);
                            
                        }
                    }

                }
                else if(choice_var_merch_menu==5)
                {
                    System.out.print("Rewards Slots are");
                    all_merchants.get(choice_var_merchant).show_slots();
                }
                else 
                {
                    break;
                }
            }
        }
        else if(choice_var==2)
        {
            while(true)
            {
                System.out.println("Welcome to Customer Menu");
                for(int m=0;m<all_customers.size();m++)
                {
                    System.out.println(m+1+") "+all_customers.get(m).getName());
                }
                System.out.println("Enter Choice");
                int var_choice_customer=inpu.nextInt();
                System.out.println("Welcome "+all_customers.get(var_choice_customer-1).getName());
                System.out.println("1) Search Items");
                System.out.println("2) Checkout Items");
                System.out.println("3) Reward Won");
                System.out.println("4) Recent Orders");
                System.out.println("Press any other key to exit");
                System.out.println("Enter Choice");
                int var_choice_customer_menu=inpu.nextInt();
                if(var_choice_customer_menu==1)
                {
                    int m_1=0;
                    Iterator<String> str1 = categories.iterator(); 
                    while (str1.hasNext())
                    {
                        m_1++;
                        System.out.println(m_1+")"+str1.next());
                    }
                    String cust_cat=inpu.nextLine();
                    for(int m_2=0;m_2<items_list_universal.size();m_2++)
                    {
                        if(items_list_universal.get(m_2).getCategory().equals(cust_cat))
                        {
                            items_list_universal.get(m_2).print();
                        }
                    }
                    System.out.println("Enter Code");
                    int code3=inpu.nextInt();
                    System.out.println("Enter Quantity");
                    int quantity_c=inpu.nextInt();
                    System.out.println("1) Buy");
                    System.out.println("2) Add to Cart");
                    System.out.println("Enter choice");
                    int buying_choice=inpu.nextInt();
                    item temp_c=new item(0, "a", 1, 1, "c", 0);
                    for(int m_3=0;m_3<items_list_universal.size();m_3++)
                    {
                        if(items_list_universal.get(m_3).getCode()==code3)
                        {
                            temp_c=items_list_universal.get(m_3);
                            break;
                        }
                    }
                    
                    all_customers.get(var_choice_customer).search_c(temp_c,quantity_c, buying_choice,items_list_universal);
                    int abc_main=0;
                    for(int abc=0;abc<all_merchants.size();abc++)
                    {
                        for(int abc1=0;abc1<all_merchants.get(abc).item_list.size();abc1++)
                        {
                            if(temp_c.getCode()==all_merchants.get(abc).item_list.get(abc1).getCode())
                            {
                                abc_main=abc;
                            }
                        }
                    }
                    all_merchants.get(abc_main).setComp_bal(temp_c.getPrice()*quantity_c*0.05);
                    all_merchants.get(abc_main).setCalc_com_bal(all_merchants.get(abc_main).getComp_bal());
                    if(all_merchants.get(abc_main).getCalc_com_bal()>100)
                    {
                        all_merchants.get(abc_main).setAllowed_length(all_merchants.get(abc_main).getAllowed_length()+1);
                        all_merchants.get(abc_main).setCalc_com_bal(all_merchants.get(abc_main).getCalc_com_bal()-100);
                        
                    }



                }
                else if(var_choice_customer_menu==2)
                {
                    all_customers.get(var_choice_customer).checkout(items_list_universal);
                    
                    
                }
                else if(var_choice_customer_menu==3)
                {
                    System.out.println("Total Reward Won: "+all_customers.get(var_choice_customer).getReward());
                }
                else if(var_choice_customer_menu==4)
                {
                    System.out.println("Order History Is");
                    for(int n_1=all_customers.get(var_choice_customer).order_history.size();n_1>all_customers.get(var_choice_customer).order_history.size()-10;n_1--){
                    System.out.println(all_customers.get(var_choice_customer).order_history.get(n_1));}
                }
                else 
                {
                    break;
                }

            }

        }
        else if(choice_var==3)
        {
            System.out.println("Enter Details");
            String stri=inpu.nextLine();
            String stri1=stri.substring(0,1);
            int idx=Integer.parseInt(stri.substring(2));
            if(stri1.equals("M"))
            {
                all_merchants.get(idx-1).print();
            }
            else 
            {
                all_customers.get(idx-1).print();
            }

        }
        else if(choice_var==4)
        {
            for(int yay=0;yay<all_merchants.size();yay++)
            {
                tot_com_bal+=all_merchants.get(yay).getComp_bal();
            }
            System.out.println("Company Balance is"+" Rs."+tot_com_bal);
        }
        else
        {
            break;
        }

    }
    System.out.println("Exiting Application.....");
    inpu.close();
  }
}