import java.util.*;
class Lab4
{
    
    public static void main(String[] args)
    {
        Scanner inpu=new Scanner(System.in);
        ArrayList <User> user_list=new ArrayList<>();
        System.out.println("Welcome to Arch Legends");
        while(true)
        {
            System.out.println("Enter Choice");
            System.out.println("1) New User");
            System.out.println("2) Existing User");
            System.out.println("3) Exit");
            int choice=inpu.nextInt();
            switch(choice)
            {
                case 1: User new_User=new User(inpu);
                        user_list.add(new_User);
                    break;
                case 2: game_starter(inpu,user_list);
                    break;
            
            }
            if(choice!=1 && choice!=2)
            {
                break;
            }
        }
        System.out.println("Exiting Game Now");
        
        inpu.close();    
    }
    public static void game_starter(Scanner inpu,ArrayList <User> user_list)
    {
        System.out.println("Enter User Name");
        inpu.nextLine();
        String uname=inpu.nextLine();
        int ind=0;
        for(int i=0;i<user_list.size();i++)
        {
            if(user_list.get(i).getUser_name().equals(uname))
            {
                System.out.println("User Found ...Logging In");
                ind=i;
            }
        }
        user_list.get(ind).start_fight(user_list.get(ind),inpu);
    }
}
class User
{
    private int special_move_counter=0;
    private boolean special_move_active;
    private final String user_name;
    private Hero chosen1;
    private String heroname;
    private int choice_of_hero;
    User(Scanner inpu)
    {
        this.special_move_active=false;
        System.out.println("Enter Username");
        inpu.nextLine();
        this.user_name=inpu.nextLine();       
       // System.out.println(user_name);
        System.out.println("Welcome ");
        System.out.println("Enter Hero Choice");
        System.out.println("1) Warrior");
        System.out.println("2) Thief");
        System.out.println("3) Mage");
        System.out.println("4) Healer");
        choice_of_hero=inpu.nextInt();
        switch (choice_of_hero) {
            case 1: this.chosen1=new Warrior();
                    this.heroname="Warrior";
                
                break;
            case 2:this.chosen1=new Thief();
                    this.heroname="Thief";
                
                break;
            case 3:this.chosen1=new Mage();
                    this.heroname="Mage";
                
                break;
            case 4:this.chosen1=new Healer();
                    this.heroname="Healer";
                
                break;
        
            default:
                System.out.println("Wrong Choice, Going Back to Main Menu");
                break;
        }
        if(this.chosen1!=null)
        {
            System.out.println("User Creation Done");
            System.out.println("Username: "+this.user_name);
            System.out.println("Hero Chosen: "+this.heroname);
        }
        


    }
    public void start_fight(User u,Scanner inpu)
    {
        Game_Layout g=new Game_Layout();
        g.show_possible_locations_1(u,inpu);
    }
    /**
     * @return the special_move_counter
     */
    public int getSpecial_move_counter() {
        return special_move_counter;
    }
    /**
     * @param special_move_counter the special_move_counter to set
     */
    public void setSpecial_move_counter(int special_move_counter) {
        this.special_move_counter = special_move_counter;
    }
    /**
     * @return the user_name
     */
    public String getUser_name() 
    {
        return user_name;
    }
    /**
     * @return the chosen1
     */
    public Hero getChosen1() {
        return chosen1;
    }
    /**
     * @param chosen1 the chosen1 to set
     */
    public void setChosen1(Hero chosen1) {
        this.chosen1 = chosen1;
    }
}
class Hero
{
    private Double xp;
    private Double hp;
    private int attackval=0;
    private int defval=0;
    private int heronum=0;
    
    Hero()
    {
        this.xp=0.0;
        this.hp=100.0;
        
    }
    /**
     * @return the attackval
     */
    public int getAttackval() {
        return attackval;
    }
    /**
     * @param heronum the heronum to set
     */
    public void setHeronum(int heronum) {
        this.heronum = heronum;
    }
    /**
     * @return the heronum
     */
    public int getHeronum() {
        return heronum;
    }
    /**
     * @param attackval the attackval to set
     */
    public void setAttackval(int attackval) {
        this.attackval = attackval;
    }
    /**
     * @return the defval
     */
    public int getDefval() {
        return defval;
    }
    /**
     * @param defval the defval to set
     */
    public void setDefval(int defval) {
        this.defval = defval;
    }
    /**
     * @return the hp
     */
    public Double getHp() {
        return hp;
    }
    /**
     * @return the xp
     */
    public Double getXp() {
        return xp;
    }
    /**
     * @param hp the hp to set
     */
    public void setHp(Double hp) {
        this.hp = hp;
    }
    /**
     * @param xp the xp to set
     */
    public void setXp(Double xp) {
        this.xp = xp;
    }
    

    public void attack(Monster unfortunate1,User current)
    {
    
    current.setSpecial_move_counter(current.getSpecial_move_counter()+1);
    System.out.println("Attack Iniating");
    unfortunate1.setHp(unfortunate1.getHp()-Double.parseDouble(String.valueOf(this.attackval)));   
    System.out.println("Attak Successful");
    
    }
    public void defense(Monster unfortunate1,User current)
    {
        current.setSpecial_move_counter(current.getSpecial_move_counter()+1);
        System.out.println("Defending");
        this.setHp(getHp()+Double.parseDouble(String.valueOf(this.defval)));
        System.out.println("Defended From Next Attack");
    }
    public void special_move()
    {
        System.out.println("Special Move Time");
    }
    public void special_move(User current)
    {
        System.out.println("Special Move Time");
    }
    public void special_move(Monster unfortunate1,User current)
    {
        System.out.println("Special Move Time");
    }

   
}
class Warrior extends Hero
{
    private int attackval=10;
    private int defval=3;
    @Override
    public void attack(Monster unfortunate1,User current) {
        super.setAttackval(this.attackval);
        super.attack(unfortunate1,current);
        System.out.println("Damage of "+attackval+" "+"dealt.");
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void defense(Monster unfortunate1,User current) {
        super.setDefval(this.defval);
        super.defense(unfortunate1,current);
        System.out.println("Monster attck reduced by "+this.defval);
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void special_move(User current)
    {
        super.setAttackval(this.attackval+5);
        super.setAttackval(this.attackval+3);
    }

   
}
class Mage extends Hero
{
    private int attackval=5;
    private int defval=5; 
    @Override
    public void attack(Monster unfortunate1,User current) {
        super.setAttackval(this.attackval);
        super.attack(unfortunate1,current);
        System.out.println("Damage of "+attackval+" "+"dealt.");
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void defense(Monster unfortunate1,User current) {
        super.setDefval(this.defval);
        super.defense(unfortunate1,current);
        System.out.println("Monster attck reduced by "+this.defval);
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void special_move(Monster unfortunate1,User current)
    {
     unfortunate1.setHp(unfortunate1.getHp()*0.95);   
    }
}
class Thief extends Hero
{
    private int attackval=6;
    private int defval=4; 
    @Override
    public void attack(Monster unfortunate1,User current) {
        super.setAttackval(this.attackval);
        super.attack(unfortunate1,current);
        System.out.println("Damage of "+attackval+" "+"dealt.");
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void defense(Monster unfortunate1,User current) {
        super.setDefval(this.defval);
        super.defense(unfortunate1,current);
        System.out.println("Monster attck reduced by "+this.defval);
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void special_move(Monster unfortunate1,User current)
    {
    double adder=0.3*unfortunate1.getHp();
    super.setHp(adder+super.getHp());   
    unfortunate1.setHp(unfortunate1.getHp()-adder);
    }

}
class Healer extends Hero
{
    private int attackval=4;
    private int defval=8; 
    @Override
    public void attack(Monster unfortunate1,User current) {
        super.setAttackval(this.attackval);
        super.attack(unfortunate1,current);
        System.out.println("Damage of "+attackval+" "+"dealt.");
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void defense(Monster unfortunate1,User current) {
        super.setDefval(this.defval);
        super.defense(unfortunate1,current);
        System.out.println("Monster attck reduced by "+this.defval);
        System.out.println("My HP: "+super.getHp());
        System.out.println("Monster's HP: "+unfortunate1.getHp());
    }
    @Override
    public void special_move()
    {
        super.setHp(super.getHp()*1.05);
    }
}
class Monster
{
    private Boolean dead_check=false;
    private String name;
    private Double hp;
    private Double lvl;
    Monster()
    {
        this.hp=0.0;
        this.name="Monster";
    }
    /**
     * @return the dead_check
     */
    public Boolean getDead_check() {
        return dead_check;
    }
    /**
     * @param dead_check the dead_check to set
     */
    public void setDead_check(Boolean dead_check) {
        this.dead_check = dead_check;
    }
    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return the hp
     */
    public Double getHp() {
        return hp;
    }
    /**
     * @param lvl the lvl to set
     */
    public void setLvl(Double lvl) {
        this.lvl = lvl;
    }
    /**
     * @return the lvl
     */
    public Double getLvl() {
        return lvl;
    }
    /**
     * @param hp the hp to set
     */
    public void setHp(Double hp) {
        this.hp = hp;
    }
    public void attack(Hero chosen1)
    {
        System.out.println("Monster Attack");
        Random attckpwr=new Random();
        Double temp=Math.min(Math.abs(attckpwr.nextGaussian()),1.0);        
        Double damage=temp*0.25*this.hp;
        chosen1.setHp(chosen1.getHp()-damage);
        System.out.println("The Monster attacked and inflicted "+damage+" damage on you");
        System.out.println("Your HP "+chosen1.getHp());
        System.out.println("Monsters HP "+this.hp);
        if (chosen1.getHp()<=0.0)
        {
            System.out.println("You are Dead, Sorry");
            System.out.println("Taking Game on Step1");
            setDead_check(true);
        }
    }
}
class Goblins extends Monster
{
    Goblins()
    {
        super.setLvl(1.0);
        super.setHp(100.0);
        super.setName("Goblin");
    }
    @Override
    public void attack(Hero chosen1) {
        super.attack(chosen1);
    }

}
class Zombies extends Monster
{
    Zombies()
    {
        super.setLvl(2.0);

        super.setHp(150.0);
        super.setName("Zombies");

    }
    @Override
    public void attack(Hero chosen1) {
        super.attack(chosen1);
    }
}
class Fiends extends Monster
{
    Fiends()
    {
        super.setLvl(3.0);

        super.setHp(200.0);
        super.setName("Fiends");

    }
    @Override
    public void attack(Hero chosen1) {
        super.attack(chosen1);
    }
}
class Lionfang extends Monster
{
    Lionfang()
    {
        super.setLvl(4.0);

        super.setHp(250.0);
        super.setName("Lionfang");

    }
    @Override
    public void attack(Hero chosen1) {
        Random temp=new Random();
        int special_move_checker=temp.nextInt(10)+1;
        if(special_move_checker==5)
        {
            System.out.println("Monster Special Attack");
            chosen1.setHp(chosen1.getHp()/2);
            System.out.println("The Monster attacked and inflicted "+chosen1.getHp()/2+" damage on you");
            System.out.println("Your HP "+chosen1.getHp());
            System.out.println("Monsters HP "+super.getHp());
            if (chosen1.getHp()==0.0)
            {
                System.out.println("You are Dead, Sorry");
                System.out.println("Taking Game on Step1");
            }

        }
        else 
        {super.attack(chosen1);}
    }
}

class Loc_Node
{
    Monster Opponent;
    Loc_Node first_next;
    Loc_Node second_next;
    Loc_Node third_next;

    Loc_Node(Monster Opponent)
    {
        this.Opponent=Opponent;    
    }
    
}

class Game_Layout{
    private final String[] lvl1choice={"123","132","231","213","321","312"};
    private final String[] lvl2choice={"564","546","645","654","465","456"};
    private final String[] lvl3choice={"897","879","978","987","798","789"};

    Monster m0=new Lionfang();
    Monster m1=new Goblins();
    Monster m2=new Zombies();
    Monster m3=new Fiends();
    Monster m4=new Goblins();
    Monster m5=new Zombies();
    Monster m6=new Fiends();
    Monster m7=new Goblins();
    Monster m8=new Zombies();
    Monster m9=new Fiends();
    Monster m10=new Lionfang();
    Loc_Node l0=new Loc_Node(m0);
    Loc_Node l1=new Loc_Node(m1);
    Loc_Node l2=new Loc_Node(m2);
    Loc_Node l3=new Loc_Node(m3);
    Loc_Node l4=new Loc_Node(m4);
    Loc_Node l5=new Loc_Node(m5);
    Loc_Node l6=new Loc_Node(m6);
    Loc_Node l7=new Loc_Node(m7);
    Loc_Node l8=new Loc_Node(m8);
    Loc_Node l9=new Loc_Node(m9);
    Loc_Node l10=new Loc_Node(m10);
    Random obj1=new Random();
    int randomiser=obj1.nextInt(6); 
    Game_Layout()
    {

    l0.first_next=l1;
    l0.second_next=l2;
    l0.third_next=l3;
    l1.first_next=l4;
    l1.second_next=l5;
    l1.third_next=l6;
    l2.first_next=l4;
    l2.second_next=l5;
    l2.third_next=l6;
    l3.first_next=l4;
    l3.second_next=l5;
    l3.third_next=l6;
    l4.first_next=l7;
    l4.second_next=l8;
    l4.third_next=l9;
    l5.first_next=l7;
    l5.second_next=l8;
    l5.third_next=l9;
    l6.first_next=l7;
    l6.second_next=l8;
    l6.third_next=l9;
    l7.first_next=l10;
    l7.second_next=l10;
    l7.third_next=l10;
    l8.first_next=l10;
    l8.second_next=l10;
    l8.third_next=l10;
    l9.third_next=l10;
    l9.first_next=l10;
    l9.second_next=l10;    
    }

    public void fight(Loc_Node curr,User currentUser,Scanner inpu)
    {
        boolean checkwork=false;
        System.out.println("Fight Starting");
        System.out.println("Your battle is "+curr.Opponent.getName());
    while(curr.Opponent.getDead_check()==false && curr.Opponent.getHp()!=0.0 ){ 
        System.out.println("1) Attack");
        System.out.println("2) Defense");
        if(currentUser.getSpecial_move_counter()==3)
        {
            System.out.println("3) Special Move");
        }
        int choice=inpu.nextInt();
        if(choice==1)
        {
            currentUser.getChosen1().attack(curr.Opponent, currentUser);
            if(curr.Opponent.getHp()==0.0)
            {
                System.out.println("Monster Killed");
                currentUser.getChosen1().setXp(currentUser.getChosen1().getXp()+20*curr.Opponent.getLvl()*20);
                checkwork=true;
                break;
            }
        }
        else if(choice==2)
        {
            currentUser.getChosen1().defense(curr.Opponent, currentUser);
        }
        else if(choice==3)
        {
            currentUser.getChosen1().special_move();

        }
        
        curr.Opponent.attack(currentUser.getChosen1());
        if(curr.Opponent.getDead_check()==true)
        {
            curr=l0;
            break;
        }
    }
        
        
    

    }
    public void show_possible_locations_1(User u,Scanner inpu)
    {
        
        
        System.out.println("Welcome to The Game");
        System.out.println("Location 1");
        System.out.println("Location 2");
        System.out.println("Location 3");
        int path_choice=inpu.nextInt();
        path_choice=path_choice-1;
        Loc_Node curr=l0;
        int[] choice_arr_1={Character.getNumericValue(lvl1choice[randomiser].charAt(0)),Character.getNumericValue(lvl1choice[randomiser].charAt(1)),Character.getNumericValue(lvl1choice[randomiser].charAt(2))};
        go_to_next_loc(u,inpu,curr, choice_arr_1[path_choice]);
    }
    public void show_possible_locations_2(User u,Loc_Node curr,Scanner inpu)
    {
        
        
        System.out.println("Chose Location");
        System.out.println("Location 4");
        System.out.println("Location 5");
        System.out.println("Location 6");
        int path_choice=inpu.nextInt()-3;
        path_choice=path_choice-1;
              
        int[] choice_arr_2={Character.getNumericValue(lvl2choice[randomiser].charAt(0)),Character.getNumericValue(lvl2choice[randomiser].charAt(1)),Character.getNumericValue(lvl2choice[randomiser].charAt(2))};
        go_to_next_loc(u,inpu,curr, choice_arr_2[path_choice]);
    }
    public void show_possible_locations_3(User u,Loc_Node curr,Scanner inpu)
    {
        
        
        System.out.println("Chose Location");
        System.out.println("Location 7");
        System.out.println("Location 8");
        System.out.println("Location 9");
        int path_choice=inpu.nextInt()-6;
        path_choice=path_choice-1;
              
        int[] choice_arr_3={Character.getNumericValue(lvl3choice[randomiser].charAt(0)),Character.getNumericValue(lvl3choice[randomiser].charAt(1)),Character.getNumericValue(lvl3choice[randomiser].charAt(2))};
        go_to_next_loc(u,inpu,curr, choice_arr_3[path_choice]);
    }
    public void show_possible_locations_4(User u,Loc_Node curr,Scanner inpu)
    {
        
        
        System.out.println("Boss Mode Time");
        System.out.println("Location 10");
        System.out.println("Location 10");
        System.out.println("Location 10");
        int path_choice=inpu.nextInt();
        path_choice=3;

        go_to_next_loc(u,inpu,curr,path_choice);
    }
    public void go_to_next_loc(User currentUser,Scanner inpu,Loc_Node curr,int check)
    {
        if(check==1)
        {
            curr=curr.first_next;
            //System.out.println("t1y");
        }
        else if(check==2)
        {
            curr=curr.second_next;
            //System.out.println("t2y");
        }
        else 
        {
            curr=curr.third_next;
            //System.out.println("t3y");
        }
        currentUser.getChosen1().setHp(100.0);
        fight(curr, currentUser, inpu);
        if(curr.Opponent.getDead_check()==true)
        {
            curr=l0;
        }
        which_loc_func(currentUser,curr, inpu);
    }
    public void which_loc_func(User u,Loc_Node curr, Scanner inpu)
    {
        if(curr==l1 || curr==l2 || curr==l3 )
        {
            show_possible_locations_2(u,curr,inpu);
        }
        else if(curr==l4 || curr==l5 || curr==l6 )
        {
            show_possible_locations_3(u,curr,inpu);
        }
        else  if(curr==l7 || curr==l8 || curr==l9 )
        {
            show_possible_locations_4(u,curr,inpu);
        }
        else if(curr==l0)
        {
            show_possible_locations_1(u,inpu);
        }
       
    }
    
}